#include <iostream>
#include <vector>

using namespace std;


int main (){

vector<int> matriz = {1,2,3,4,5,6,7,8,9,10};

for (int elemento : matriz){
    cout << elemento << endl;
}
    return 0;
}
