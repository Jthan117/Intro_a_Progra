  // TODO: quite el comentario de la funcion para mostrar su board!
  // PrintBoard(board);