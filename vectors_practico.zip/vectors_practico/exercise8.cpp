#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main (){

vector<int> meses = {31,28,31,30,31,30,30,31,30,31,30,31}; //se lo debo

 

    return 0;
}
